package com.abt.skillzage;

import static com.facebook.appevents.UserDataStore.EMAIL;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.abt.skillzage.widget.SharedPrefUtil;
import com.google.android.material.button.MaterialButton;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONObject;

import java.util.Arrays;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;

public class EmailAuthenticationScreen extends AppCompatActivity {

    private MaterialButton btnLogin;
    private com.google.android.material.textfield.TextInputEditText editUsername , editPassword;
    private androidx.appcompat.widget.AppCompatTextView btnRegister;
    private androidx.appcompat.widget.AppCompatCheckBox rememberme , checkTerms;
    private int session_in = 0;
    private AppCompatImageView fb_btn  , google_btn ;
    private com.facebook.login.widget.LoginButton fblogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_authentication_screen);

        initLayout();
    }

    private void initLayout() {
        btnLogin = findViewById(R.id.btnLogin);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        checkTerms = findViewById(R.id.checkTerms);
        fblogin = findViewById(R.id.fb_login_button);
        fb_btn =  findViewById(R.id.fb_btn);
//        fb_btn.setReadPermissions(Arrays.asList(EMAIL));
//        fb_btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });

        checkTerms.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    new AlertDialog.Builder(EmailAuthenticationScreen.this)
                            .setTitle("Terms & Conditions")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    SharedPrefUtil.with(EmailAuthenticationScreen.this).addString("agreed", "true").save();
                                    checkTerms.setChecked(true);
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    checkTerms.setChecked(false);
                                }
                            })
                            .setMessage(getResources().getString(R.string.sample_logn_text))
                            .show();
                }
            }
        });
        editUsername.setText("basuarbind@gmail.com");
        editPassword.setText("123456");
        btnRegister = findViewById(R.id.btnRegister);
        rememberme = findViewById(R.id.rememberme);
        rememberme.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    session_in = 1;
                }else{
                    session_in = 0;
                }
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editUsername.getText().toString().isEmpty()){
                    Toast.makeText(EmailAuthenticationScreen.this,
                            "Email field is required", Toast.LENGTH_LONG).show();
                    return;
                }

                if(editPassword.getText().toString().isEmpty()){
                    Toast.makeText(EmailAuthenticationScreen.this,
                            "Password field is required", Toast.LENGTH_LONG).show();
                    return;
                }

                if(!checkTerms.isChecked()){
                    Toast.makeText(EmailAuthenticationScreen.this,
                            "Please accept terms and conditions", Toast.LENGTH_LONG).show();
                    return;
                }

                doLoginPost(editUsername.getText().toString() , editPassword.getText().toString());
            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EmailAuthenticationScreen.this, OnBoarding.class));
            }
        });
    }



    public void doLoginPost(String username , String password) {

        String url = getResources().getString(R.string.baseurl)+"skillzag/auth/users/login";
        final ProgressDialog progressDialog = new ProgressDialog(EmailAuthenticationScreen.this);
        progressDialog.setMessage("Loading....Please wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        AsyncHttpClient client = new AsyncHttpClient();
        JSONObject params = new JSONObject();
        StringEntity entity = null;
        try {
            params.put("email",username);
            params.put("password",password);
            entity = new StringEntity(params.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        client.post(EmailAuthenticationScreen.this , url, entity , "application/json" , new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                System.out.println("Error  Response from server recved is   " + responseString);
                progressDialog.dismiss();
                Toast.makeText(EmailAuthenticationScreen.this, "Error in make your Request . Please try again.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                System.out.println(" Success Response from server recved is   " + responseString);
                try {
                    progressDialog.dismiss();
                    JSONObject mainaobj = new JSONObject(responseString);
                    if(mainaobj.has("status")){
                        if(mainaobj.getString("status").equalsIgnoreCase("success")){
                            SharedPrefUtil.with(EmailAuthenticationScreen.this).addString("userid" , mainaobj.getString("email")).save();
                            SharedPrefUtil.with(EmailAuthenticationScreen.this).addString("role" , mainaobj.getString("role")).save();
                            if(session_in == 1){
                                SharedPrefUtil.with(EmailAuthenticationScreen.this).addString("token" , mainaobj.getString("token")).save();
                                SharedPrefUtil.with(EmailAuthenticationScreen.this).addString("sessionmob" , "1").save();
                            }else{

                            }
                            startActivity(new Intent(EmailAuthenticationScreen.this, MainActivity.class));
                        }else{
                            Toast.makeText(EmailAuthenticationScreen.this, " Wrong Credentials. Please try again ", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(EmailAuthenticationScreen.this, " Wrong Credentials. Please try again ", Toast.LENGTH_SHORT).show();
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
    }
}