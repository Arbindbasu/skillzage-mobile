package com.abt.skillzage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.abt.skillzage.widget.SharedPrefUtil;
import com.google.android.material.button.MaterialButton;

public class WelcomeScreen extends AppCompatActivity {

    private MaterialButton btnFacebook;
    private MaterialButton btnLinkedIn;
    private MaterialButton btnEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_screen);

        if(SharedPrefUtil.with(WelcomeScreen.this).getString("sessionmob","") != null
        && !SharedPrefUtil.with(WelcomeScreen.this).getString("sessionmob","").equalsIgnoreCase("null")
                && !SharedPrefUtil.with(WelcomeScreen.this).getString("sessionmob","").isEmpty()){
            if(SharedPrefUtil.with(WelcomeScreen.this).getString("sessionmob","").equalsIgnoreCase("1")){
                startActivity(new Intent(WelcomeScreen.this, MainActivity.class));
                finish();
            }else{
                initLayout();
            }
        }else{
            initLayout();
        }
    }

    private void initLayout(){
        btnFacebook = findViewById(R.id.btnFacebook);
        btnLinkedIn = findViewById(R.id.btnLinkedIn);
        btnEmail = findViewById(R.id.btnEmail);

        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //throw new RuntimeException("Test Crash");
                  startActivity(new Intent(WelcomeScreen.this, EmailAuthenticationScreen.class));
            }
        });
    }
}