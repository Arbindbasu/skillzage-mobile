package com.abt.skillzage.ui.achievement;

import androidx.lifecycle.ViewModel;

public class AchievementViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}