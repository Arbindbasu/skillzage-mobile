package com.abt.skillzage.ui.checkout;

import androidx.lifecycle.ViewModel;

public class CheckoutViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}