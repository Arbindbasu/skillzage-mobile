package com.abt.skillzage.ui.project_detail;

import androidx.lifecycle.ViewModel;

public class ProjectDetailViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}