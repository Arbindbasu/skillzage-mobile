package com.abt.skillzage.ui.cart;

import androidx.lifecycle.ViewModel;

public class MyCartViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}