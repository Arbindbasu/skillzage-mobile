package com.abt.skillzage.ui.chat_group;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.abt.skillzage.R;
import com.abt.skillzage.adapter.ChatGrpAdapter;

public class ChatGroup extends Fragment {

    private ChatGroupViewModel mViewModel;

    public static ChatGroup newInstance() {
        return new ChatGroup();
    }

    private View rootView;
    private AppCompatTextView labelActiveChats;
    private AppCompatTextView labelOldChats;
    private RecyclerView activeChatGrpList;
    private RecyclerView oldChatGrpList;
    private boolean isActiveChatVisible = true;
    private boolean isOldChatVisible = false;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.chat_group_fragment, container, false);
        labelActiveChats = rootView.findViewById(R.id.labelActiveChats);
        labelOldChats = rootView.findViewById(R.id.labelOldChats);
        activeChatGrpList = rootView.findViewById(R.id.activeChartGrpList);
        oldChatGrpList = rootView.findViewById(R.id.oldChatGrpList);

        labelActiveChats.setCompoundDrawablesWithIntrinsicBounds(null,null, ContextCompat.getDrawable(getActivity(),R.drawable.ic_arrow_up), null);
        activeChatGrpList.setLayoutManager(new LinearLayoutManager(getActivity()));
        activeChatGrpList.setAdapter(new ChatGrpAdapter());
        activeChatGrpList.setVisibility(View.VISIBLE);

        oldChatGrpList.setLayoutManager(new LinearLayoutManager(getActivity()));
        oldChatGrpList.setAdapter(new ChatGrpAdapter());

        labelActiveChats.setOnClickListener(v -> {
            if (isActiveChatVisible) {
                isActiveChatVisible = false;
                activeChatGrpList.setVisibility(View.GONE);
                labelActiveChats.setCompoundDrawablesWithIntrinsicBounds(null,null, ContextCompat.getDrawable(getActivity(),R.drawable.ic_arrow_down), null);
            } else {
                isActiveChatVisible = true;
                activeChatGrpList.setVisibility(View.VISIBLE);
                labelActiveChats.setCompoundDrawablesWithIntrinsicBounds(null,null, ContextCompat.getDrawable(getActivity(),R.drawable.ic_arrow_up), null);
            }
        });

        labelOldChats.setOnClickListener(v -> {
            if (isOldChatVisible) {
                isOldChatVisible = false;
                oldChatGrpList.setVisibility(View.GONE);
                labelOldChats.setCompoundDrawablesWithIntrinsicBounds(null,null, ContextCompat.getDrawable(getActivity(),R.drawable.ic_arrow_down), null);
            } else {
                isOldChatVisible = true;
                oldChatGrpList.setVisibility(View.VISIBLE);
                labelOldChats.setCompoundDrawablesWithIntrinsicBounds(null,null, ContextCompat.getDrawable(getActivity(),R.drawable.ic_arrow_up), null);
            }
        });
        return rootView;
    }
}