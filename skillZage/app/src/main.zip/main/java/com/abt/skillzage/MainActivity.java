package com.abt.skillzage;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import static androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.abt.skillzage.model.CourseModel;
import com.abt.skillzage.ui.achievementlist.model.AchievementModel;
import com.abt.skillzage.ui.course.CourseFragment;
import com.abt.skillzage.ui.project.model.ProjectModel;
import com.abt.skillzage.widget.SharedPrefUtil;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    private AppCompatImageView btnHome;
    private CourseModel model;
    public int courseId = 0;
    public String course_image = "";
    private CourseFragment courseFragment;
    private BottomNavigationView navView;

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourse_image() {
        return course_image;
    }

    public void setCourse_image(String course_image) {
        this.course_image = course_image;
    }

    public CourseModel getModel() {
        return model;
    }

    public void setModel(CourseModel model) {
        this.model = model;
    }

    public ProjectModel projectModel;

    public ProjectModel getProjectModel() {
        return projectModel;
    }

    public void setProjectModel(ProjectModel projectModel) {
        this.projectModel = projectModel;
    }

    private AchievementModel achievementListmodel;

    androidx.appcompat.widget.AppCompatImageView btnProfile;

    public AchievementModel getAchievementListmodel() {
        return achievementListmodel;
    }

    public void setAchievementListmodel(AchievementModel achievementListmodel) {
        this.achievementListmodel = achievementListmodel;
    }

    public String project_navigation_status = "0";

    public String getProject_navigation_status() {
        return project_navigation_status;
    }

    public void setProject_navigation_status(String project_navigation_status) {
        this.project_navigation_status = project_navigation_status;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setSupportActionBar(findViewById(R.id.toolbar));
        btnProfile = findViewById(R.id.btnProfile);
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Confirmation")
                        .setMessage(" Do you  want to Logout ? ")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();

                            }
                        })
                        .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener(){
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                                SharedPrefUtil.with(MainActivity.this).clearAll().save();
                                startActivity(new Intent(MainActivity.this , EmailAuthenticationScreen.class));
                                finish();
                            }}).show();
            }
        });
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_book, R.id.navigation_search, R.id.navigation_notifications, R.id.navigation_profile,
                R.id.navigation_course, R.id.navigation_allcourse, R.id.navigation_knowledgehub, R.id.navigation_announcements,
                R.id.navigation_chatgroup, R.id.navigation_careerpath, R.id.navigation_achievement, R.id.navigation_projet_detail,
                R.id.navigation_course_detail, R.id.navigation_test_ur_self
                , R.id.navigation_all_projects)
                .build();
        NavController navController = Navigation.findNavController(MainActivity.this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(MainActivity.this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);



        btnHome = findViewById(R.id.btnHome);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

//    private final BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
//            = item -> {
//        switch (item.getItemId()) {
//            case R.id.navigation_book:
//                courseFragment = new CourseFragment();
//                viewFragment(courseFragment, "COURSE");
//                return true;
//
//        }
//        return false;
//    };


}