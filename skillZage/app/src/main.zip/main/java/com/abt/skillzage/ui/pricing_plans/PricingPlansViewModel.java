package com.abt.skillzage.ui.pricing_plans;

import androidx.lifecycle.ViewModel;

public class PricingPlansViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}