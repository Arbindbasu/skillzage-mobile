package com.abt.skillzage.ui.chat_group;

import androidx.lifecycle.ViewModel;

public class ChatGroupViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}