package com.abt.skillzage.ui.payment;

import androidx.lifecycle.ViewModel;

public class PaymentViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}