package com.abt.skillzage.ui.session_detail;

import androidx.lifecycle.ViewModel;

public class SessionDetailViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}