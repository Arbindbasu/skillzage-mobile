package com.abt.skillzage.ui.course_detail;

import androidx.lifecycle.ViewModel;

public class CourseDetailViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}