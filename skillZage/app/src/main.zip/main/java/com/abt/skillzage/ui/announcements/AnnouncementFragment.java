package com.abt.skillzage.ui.announcements;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.abt.skillzage.R;
import com.abt.skillzage.adapter.AnnouncementListAdapter;

public class AnnouncementFragment extends Fragment {

    private AnnouncementViewModel mViewModel;

    private View rootView;
    private RecyclerView annoucementList;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.announcement_fragment, container, false);
        annoucementList = rootView.findViewById(R.id.annoucementList);
        annoucementList.setLayoutManager(new LinearLayoutManager(getActivity()));
        annoucementList.setNestedScrollingEnabled(false);
        annoucementList.setAdapter(new AnnouncementListAdapter());
        return rootView;
    }

}