package com.abt.skillzage.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.abt.skillzage.R;
import com.squareup.picasso.Picasso;

public class CompletedProjectAdapter extends RecyclerView.Adapter<CompletedProjectAdapter.CompletedProjectViewHolder> {
    @NonNull
    @Override
    public CompletedProjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.project_layout, parent, false);
        return new CompletedProjectViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CompletedProjectViewHolder holder, int position) {
        if(position%2 == 0){
            Picasso.get().load("http://skillsage.peeqer.com/img/course2.png").into(holder.projectImg);
        }else{
            Picasso.get().load("http://skillsage.peeqer.com/img/course1.png").into(holder.projectImg);
        }
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class CompletedProjectViewHolder extends RecyclerView.ViewHolder {

        private AppCompatImageView projectImg;

        public CompletedProjectViewHolder(@NonNull View itemView) {
            super(itemView);
            projectImg = itemView.findViewById(R.id.projectImg);
        }
    }
}
