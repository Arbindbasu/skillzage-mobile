package com.abt.skillzage.ui.career_path;

import androidx.lifecycle.ViewModel;

public class CareerPathViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}