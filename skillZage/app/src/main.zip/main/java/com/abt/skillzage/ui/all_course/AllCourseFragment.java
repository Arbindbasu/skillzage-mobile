package com.abt.skillzage.ui.all_course;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.abt.skillzage.EmailAuthenticationScreen;
import com.abt.skillzage.MainActivity;
import com.abt.skillzage.R;
import com.abt.skillzage.adapter.CourseListAdapter;
import com.abt.skillzage.model.CourseModel;
import com.google.android.material.button.MaterialButton;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class AllCourseFragment extends Fragment {

    private View rootView;
    private MaterialButton btnCourses;
    private RecyclerView courseList;
    private List<CourseModel> listCourseModel = new ArrayList<>();
    androidx.appcompat.widget.SearchView searchcourse;
    CourseListAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_all_course, container, false);
        btnCourses = rootView.findViewById(R.id.btnCourses);
        searchcourse = rootView.findViewById(R.id.searchCourses);
        courseList = rootView.findViewById(R.id.courseList);
        courseList.setLayoutManager(new LinearLayoutManager(getActivity()));
      //  courseList.setNestedScrollingEnabled(false);
        adapter = new CourseListAdapter();
        adapter.listCourseModel = listCourseModel;
        adapter.context = getActivity();
        courseList.setAdapter(adapter);
        doGetAllCourses();

        searchcourse.setOnQueryTextListener(new androidx.appcompat.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                //  filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return true;
            }
        });

        btnCourses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(rootView).navigate(R.id.navigation_course);
            }
        });

        return rootView;
    }


    public void doGetAllCourses() {

        String url = getResources().getString(R.string.baseurl3)+"api/courses-managements";
        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading....Please wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        AsyncHttpClient client = new AsyncHttpClient();

        client.get(url, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                System.out.println("Error  Response from server recved is   " + responseString);
                progressDialog.dismiss();
                Toast.makeText(getActivity(), "Error in make your Request . Please try again.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                System.out.println(" Success Response from server recved is   " + responseString);
                try {
                    progressDialog.dismiss();
                    listCourseModel.clear();
                    JSONArray mainarr = new JSONArray(responseString);
                    for(int t=0; t < mainarr.length();t++){
                        CourseModel courseModel = new CourseModel();
                        courseModel.setCourseId(mainarr.getJSONObject(t).getInt("id"));
                        courseModel.setCourseName(mainarr.getJSONObject(t).getString("courseName"));
                        courseModel.setCourseDescription(mainarr.getJSONObject(t).getString("courseDescription"));
                        courseModel.setCourseObjective(mainarr.getJSONObject(t).getString("courseObjective"));
                        courseModel.setCourseStatus(mainarr.getJSONObject(t).getString("courseStatus"));
                        courseModel.setImagePath(mainarr.getJSONObject(t).getString("imagePath"));
                        courseModel.setRecommendedStatus(mainarr.getJSONObject(t).getString("recommendedStatus"));
                        listCourseModel.add(courseModel);
                    }

                    adapter.listCourseModel = listCourseModel;
                    adapter.notifyDataSetChanged();

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

    public void filter(String text){
        List<CourseModel> temp = new ArrayList();
        for(CourseModel d: listCourseModel){
            //or use .equal(text) with you want equal match
            //use .toLowerCase() for better matches
            System.out.println( "   search value   is :  "+d.getCourseName().contains(text));
            if(d.getCourseName().toLowerCase().contains(text.toLowerCase())){
                temp.add(d);
            }
        }
        if(text.isEmpty()){
            adapter.listCourseModel = listCourseModel;
        }else{
            adapter.listCourseModel = temp;
        }
        //update recyclerview
        adapter.notifyDataSetChanged();
    }



}