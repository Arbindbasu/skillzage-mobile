package com.abt.skillzage.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.abt.skillzage.R;
import com.squareup.picasso.Picasso;

public class ChatGrpAdapter extends RecyclerView.Adapter<ChatGrpAdapter.ChatGrpListViewHolder> {

    private Context context;

    @NonNull
    @Override
    public ChatGrpListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_course_layout, parent, false);
        return new ChatGrpListViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatGrpListViewHolder holder, int position) {
        if(position%2 == 0){
            Picasso.get().load("http://skillsage.peeqer.com/img/course2.png").into(holder.courseImage);
        }else{
            Picasso.get().load("http://skillsage.peeqer.com/img/course1.png").into(holder.courseImage);
        }
    }

    @Override
    public int getItemCount() {
        return 2;
    }

    public class ChatGrpListViewHolder extends RecyclerView.ViewHolder {

        private AppCompatImageView courseImage;

        public ChatGrpListViewHolder(@NonNull View itemView) {
            super(itemView);
            courseImage = itemView.findViewById(R.id.courseImg);
        }
    }
}
