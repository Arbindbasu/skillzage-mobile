package com.abt.skillzage.ui.achievementlist;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.Toast;

import com.abt.skillzage.EmailAuthenticationScreen;
import com.abt.skillzage.MainActivity;
import com.abt.skillzage.R;
import com.abt.skillzage.adapter.AchievementListAdapter;
import com.abt.skillzage.adapter.CourseActiveListAdapter;
import com.abt.skillzage.adapter.CourseListAdapter;
import com.abt.skillzage.model.CourseModel;
import com.abt.skillzage.ui.achievementlist.model.AchievementModel;
import com.abt.skillzage.widget.SharedPrefUtil;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.TextHttpResponseHandler;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;


public class AchievementListFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private View rootView;
    private androidx.recyclerview.widget.RecyclerView achievementList;
    private com.google.android.material.button.MaterialButton btnAddAchievement;

    public AchievementListFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_achievement_list, container, false);
        btnAddAchievement = rootView.findViewById(R.id.btnAddAchievement);
        achievementList  = rootView.findViewById(R.id.achievementList);
        achievementList.setLayoutManager(new LinearLayoutManager(getActivity()));

        doGetAllAchievements();

        btnAddAchievement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddAchievementDialog();
            }
        });

        return rootView;
    }

    public void doGetAllAchievements() {

        String url = getResources().getString(R.string.baseurl4)+"api/achievements";
        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading....Please wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        AsyncHttpClient client = new AsyncHttpClient();
        client.get(url, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                System.out.println("Error  Response from server recved is   " + responseString);
                progressDialog.dismiss();
                Toast.makeText(getActivity(), "Error in make your Request . Please try again.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                System.out.println(" Success Response from server recved is   " + responseString);
                try {
                    progressDialog.dismiss();
                    List<AchievementModel> listAchievement = new ArrayList<>();
                    JSONArray mainarr = new JSONArray(responseString);

                    for(int t=0; t < mainarr.length();t++){

                            AchievementModel achievementModel = new AchievementModel();
                            achievementModel.setId(mainarr.getJSONObject(t).getInt("id"));
                            achievementModel.setCertificateDescription(mainarr.getJSONObject(t).getString("certificateDescription"));
                            achievementModel.setCertificationTitle(mainarr.getJSONObject(t).getString("certificationTitle"));
                            achievementModel.setCertificationType(mainarr.getJSONObject(t).getString("certificationType"));
                            achievementModel.setDateOfCompletion(mainarr.getJSONObject(t).getString("dateOfCompletion"));
                            achievementModel.setUploadCertificate(mainarr.getJSONObject(t).getString("uploadCertificate"));
                            achievementModel.setCertificationScore(mainarr.getJSONObject(t).getInt("certificationScore"));
                            listAchievement.add(achievementModel);

                    }

                    System.out.println(listAchievement.size()+"    Active list size :::   "+listAchievement.size());
                    AchievementListAdapter adapter = new AchievementListAdapter();
                    adapter.listAchievement = listAchievement;
                    adapter.context = getActivity();
                    achievementList.setAdapter(adapter);

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

    public void doAddAchievementPost(String certificateDescription , String certificationScore
            , String certificationTitle , String certificationType , String dateOfCompletion
            , String uploadCertificate) {

        String url = getResources().getString(R.string.baseurl4)+"api/achievements";
        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading....Please wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();


        AsyncHttpClient client = new AsyncHttpClient();
        JSONObject params = new JSONObject();
        StringEntity entity = null;
        try {
            params.put("certificateDescription",certificateDescription);
            params.put("certificationScore",certificationScore);
            params.put("certificationTitle",certificationTitle);
            params.put("certificationType",certificationType);
            params.put("dateOfCompletion",dateOfCompletion);
            params.put("uploadCertificate",uploadCertificate);
            entity = new StringEntity(params.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        client.post(getActivity() , url, entity , "application/json" , new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                System.out.println("Error  Response from server recved is   " + responseString);
                progressDialog.dismiss();
                Toast.makeText(getActivity(), "Error in make your Request . Please try again.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                System.out.println(" Success Response from server recved is   " + responseString);
                try {
                    progressDialog.dismiss();
                    JSONObject mainaobj = new JSONObject(responseString);
                    if(mainaobj.has("certificationTitle")){
                            Toast.makeText(getActivity(), " Saved ", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(getActivity(), "  Please try again ", Toast.LENGTH_SHORT).show();
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

    public void openAddAchievementDialog(){
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        // ...Irrelevant code for customizing
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.alert_add_achievement, null);
        dialogBuilder.setView(dialogView);

        com.google.android.material.textfield.TextInputEditText editCertificateTitle = dialogView.findViewById(R.id.editCertificateTitle);
        com.google.android.material.textfield.TextInputEditText editCertificateDescription = dialogView.findViewById(R.id.editCertificateDescription);
        com.google.android.material.textfield.TextInputEditText editCertificatedate = dialogView.findViewById(R.id.editCertificatedate);
        com.google.android.material.textfield.TextInputEditText editCertificateuploadfile = dialogView.findViewById(R.id.editCertificateuploadfile);
        com.google.android.material.button.MaterialButton btnaddachievement = dialogView.findViewById(R.id.btnaddachievement);
        com.google.android.material.textfield.TextInputEditText editCertificatescore = dialogView.findViewById(R.id.editCertificatescore);


        final Calendar myCalendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear+1);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                String myFormat = "yyyy-MM-dd'T'HH:mm:ss.000'Z'"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                editCertificatedate.setText(sdf.format(myCalendar.getTime()));
            }
        };

        editCertificatedate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 // TODO Auto-generated method stub
                new DatePickerDialog(getActivity(), date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH+1),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        btnaddachievement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doAddAchievementPost(editCertificateDescription.getText().toString() ,
                        editCertificatescore.getText().toString() ,
                        editCertificateTitle.getText().toString() ,
                        "EXTERNAL" ,editCertificatedate.getText().toString() ,
                        editCertificateuploadfile.getText().toString());
            }
        });

        AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();

    }
}