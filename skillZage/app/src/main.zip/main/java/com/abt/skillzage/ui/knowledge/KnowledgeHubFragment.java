package com.abt.skillzage.ui.knowledge;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.abt.skillzage.R;
import com.abt.skillzage.adapter.CourseListAdapter;
import com.squareup.picasso.Picasso;

public class KnowledgeHubFragment extends Fragment {

    private View rootView;
    private AppCompatImageView instituteBanner;
    private AppCompatImageView institution_logo;
    private RecyclerView institutionCourseList;
    private RecyclerView projectsList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_knowledge_hub, container, false);
        instituteBanner = rootView.findViewById(R.id.instituteBanner);
        institutionCourseList = rootView.findViewById(R.id.institutionCourseList);
        projectsList = rootView.findViewById(R.id.projectsList);
        institution_logo = rootView.findViewById(R.id.institution_logo);
        Picasso.get().load("http://skillsage.peeqer.com/img/instbg.png").into(instituteBanner);
        Picasso.get().load("http://skillsage.peeqer.com/img/CLogow.png").into(institution_logo);

        //Project list
        projectsList.setLayoutManager(new LinearLayoutManager(getActivity()));
        projectsList.setNestedScrollingEnabled(false);
        projectsList.setAdapter(new CourseListAdapter());

        //Institution course list
        institutionCourseList.setLayoutManager(new LinearLayoutManager(getActivity()));
        institutionCourseList.setNestedScrollingEnabled(false);
        institutionCourseList.setAdapter(new CourseListAdapter());
        return rootView;
    }
}