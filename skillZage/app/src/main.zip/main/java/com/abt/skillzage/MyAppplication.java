package com.abt.skillzage;

import android.app.Application;
public class MyAppplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

    }
}
