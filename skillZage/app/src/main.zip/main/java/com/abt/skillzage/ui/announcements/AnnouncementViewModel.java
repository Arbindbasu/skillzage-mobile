package com.abt.skillzage.ui.announcements;

import androidx.lifecycle.ViewModel;

public class AnnouncementViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}